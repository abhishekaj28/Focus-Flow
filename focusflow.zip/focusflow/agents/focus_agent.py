class FocusAgent:
    def is_focused(self, focus_mode: bool) -> bool:
        return focus_mode
