class ClassifyAgent:
    IMPORTANT_APPS = {"calls", "calendar", "messages", "slack"}

    def classify(self, notification):
        if notification.app.lower() in self.IMPORTANT_APPS:
            return "ALLOW"

        if "urgent" in notification.message.lower():
            return "ALLOW"

        return "QUEUE"
