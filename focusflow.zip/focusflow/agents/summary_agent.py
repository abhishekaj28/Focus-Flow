import os
from google import genai


class SummaryAgent:
    """
    SummaryAgent uses Gemini for summarization only.
    No decision-making happens here.
    """

    def __init__(self):
        self.client = genai.Client(
            api_key=os.getenv("GEMINI_API_KEY")
        )

    def summarize(self, notifications):
        if not notifications:
            return {
                "total_notifications": 0,
                "summary": "No notifications while you were focused."
            }

        notification_text = "\n".join(
            f"- App: {n.app}, Title: {n.title}, Message: {n.message}"
            for n in notifications
        )

        prompt = f"""
You are a focus assistant.

Summarize in two sentences. Do not use markdown or special formatting.
Group similar notifications and highlight anything important.
Do not invent information.

Notifications:
{notification_text}
"""

        try:
            response = self.client.models.generate_content(
                model="models/gemini-flash-lite-latest",
                contents=prompt
            )
            summary_text = response.text.strip()
        except Exception as e:
            print("❌ GEMINI ERROR:", e)
            summary_text = f"You received {len(notifications)} notifications."

        return {
            "total_notifications": len(notifications),
            "summary": summary_text
        }
