🔁 Overall Workflow (End-to-End)

Frontend / Client sends a notification
→ via POST /api/notify

Backend detects focus state

If focus mode is ON → prioritize

If OFF → allow directly

Notification is classified

Allowed immediately

Or queued for later

Queued notifications are stored

In-memory (MVP)

When focus ends

Frontend calls GET /api/summary

Gemini summarizes queued notifications

Fallback summary is used if Gemini is unavailable

___________________________________________________________________________

📄 File-by-File Explanation --------------------------------------------

🔹 main.py

Entry point of the backend

Initializes FastAPI app

Registers routes

Enables CORS for frontend integration

Runs the backend server
_______________________________________________________________________


🔹 routes/notifications.py

API layer

Defines all HTTP endpoints:

POST /api/notify

Receives notification payloads

GET /api/summary

Returns summarized notifications

This layer:

Does NOT contain logic

Simply passes data to services
___________________________________________________

🔹 services/notification_service.py

Orchestrator / Brain Coordinator

This is the central workflow controller.

Responsibilities:

Accepts incoming notifications

Calls focus detection agent

Calls classification agent

Pushes notifications into queue if needed

Triggers summary agent when requested

Think of this as:

“Glue code that connects all agents together.”

__________________________________________________________
🔹 agents/focus_agent.py

Context Observer

Determines whether the user is in focus mode

Reads focus state sent by frontend (MVP)

Can later be extended to infer focus automatically

Purely deterministic — no AI here.
___________________________________________________________-
🔹 agents/classification_agent.py

Decision-Making Agent

This is the core autonomous agent.

It:

Evaluates each notification

Considers:

App type

Notification urgency

Focus state

Decides:

ALLOW

QUEUE

_________________________________________________________________--

🔹 agents/summary_agent.py

Reasoning Agent (Gemini-powered)

Used only when focus ends.

Responsibilities:

Takes queued notifications

Sends them to Gemini

Produces a human-readable summary

Important design choice:

Gemini does not make decisions

Gemini only explains outcomes

If Gemini fails or is rate-limited:

A deterministic fallback summary is returned

_________________________________________________________________--

🔹 models/notification.py

Data model

Defines the structure of a notification:

App name

Title

Message

Timestamp

Ensures consistency across the system.
_________________________________________________________________--

🔹 storage/queue.py

Temporary storage layer

Stores queued notifications during focus mode

In-memory for MVP

Designed to be replaced with Redis / DB later
