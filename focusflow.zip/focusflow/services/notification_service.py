from focusflow.agents.focus_agent import FocusAgent
from focusflow.agents.classify_agent import ClassifyAgent
from focusflow.agents.summary_agent import SummaryAgent
from focusflow.services.queue_service import QueueService



class NotificationService:
    """
    Orchestrates the full focusFlow agent workflow
    """

    def __init__(self):
        self.focus_agent = FocusAgent()
        self.classify_agent = ClassifyAgent()
        self.summary_agent = SummaryAgent()
        self.queue_service = QueueService()

    def handle_notification(self, notification, focus_mode: bool):
        """
        Main entry point for every incoming notification
        """

        # 1. Detect focus
        is_focused = self.focus_agent.is_focused(focus_mode)

        # 2. Classify notification
        decision = self.classify_agent.classify(notification)

        # 3. Decision logic
        if not is_focused:
            return {
                "action": "ALLOW",
                "reason": "User not in focus mode",
                "notification": notification
            }

        if decision == "ALLOW":
            return {
                "action": "ALLOW",
                "reason": "High priority notification",
                "notification": notification
            }

        # 4. Queue non-essential notifications
        self.queue_service.add(notification)

        return {
            "action": "QUEUED",
            "reason": "User in focus mode",
        }

    def summarize(self):
        """
        Summarize all queued notifications
        """
        queued = self.queue_service.flush()
        return self.summary_agent.summarize(queued)
