class QueueService:
    def __init__(self):
        self._queue = []

    def add(self, notification):
        self._queue.append(notification)

    def flush(self):
        data = self._queue
        self._queue = []
        return data
