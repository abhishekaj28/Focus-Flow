from fastapi import APIRouter
from focusflow.models.notification import Notification
from focusflow.services.notification_service import NotificationService

router = APIRouter()
service = NotificationService()

@router.post("/notify")
def notify(notification: Notification, focus_mode: bool):
    return service.handle_notification(notification, focus_mode)

@router.get("/summary")
def summary():
    return service.summarize()
