from pydantic import BaseModel
from datetime import datetime


class Notification(BaseModel):
    id: str
    app: str
    title: str
    message: str
    timestamp: datetime
