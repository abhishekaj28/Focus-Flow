from fastapi import FastAPI
from focusflow.routes.notifications import router

app = FastAPI(title="focusFlow Backend")

app.include_router(router, prefix="/api")
